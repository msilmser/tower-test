Documentation avaialble here 
https://confluence.capgroup.com/display/API/Automated+Application+Deployment+for+Weblogic+Apps
